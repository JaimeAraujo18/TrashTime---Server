<div class="footer bg-dark footer-middle col-md-12 h-25">
	<p class="py-3 col-md-12 m-0 text-center">₢ Copyright 2018 - Todos os direitos reservados</p>
</div>